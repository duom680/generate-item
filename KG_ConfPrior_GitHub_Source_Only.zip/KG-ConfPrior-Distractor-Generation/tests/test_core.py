"""Self-contained validation; no data files, credentials or network calls."""

import csv
import json
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from concept_distractors.generation import CandidateGenerator, parse_candidates
from concept_distractors.graph import KnowledgeGraph
from concept_distractors.prior import prepare_item
from concept_distractors.prompts import SYSTEM_PROMPT, build_user_prompt
from concept_distractors.ranking import HybridSimilarity, QualityConfig, _percentile, rank_item


class PipelineTests(unittest.TestCase):
    def test_prepare_knowledge_graph(self):
        with tempfile.TemporaryDirectory() as folder:
            nodes = Path(folder, "nodes.csv")
            edges = Path(folder, "edges.csv")
            nodes.write_text("id,name\n1,植物\n2,乔木\n3,灌木\n4,叶片\n", encoding="utf-8")
            edges.write_text("source,relation,target\n2,属于,1\n3,属于,1\n2,具有属性,4\n", encoding="utf-8")
            graph = KnowledgeGraph.load(nodes, edges)
            item = {"id": "dummy", "question": "下列哪一种属于植物？", "correct_answer": "乔木"}
            prepared = prepare_item(item, graph, hop=2)
            self.assertIn("乔木", str(prepared["linked_seed_entities"]))
            self.assertIn("灌木", prepared["kg_neighbors"])
            self.assertTrue(prepared["kg_paths"])

    def test_prompt_and_dedup(self):
        item = {"id": "dummy", "question": "某项概念题干", "correct_answer": "正解", "confusion_prior": ["同层概念混淆"]}
        self.assertIn("题干", SYSTEM_PROMPT)
        self.assertIn("某项概念题干", build_user_prompt(item))
        response = json.dumps({"distractors": [
            {"text": "候选甲", "confusion_type": "同层概念混淆", "reason": "类别混淆"},
            {"text": "候选甲", "confusion_type": "同层概念混淆", "reason": "重复"},
            {"text": "正解", "confusion_type": "同层概念混淆", "reason": "应过滤"},
        ]}, ensure_ascii=False)
        self.assertEqual([x["text"] for x in parse_candidates(response, "正解")], ["候选甲"])

    def test_generation_without_network(self):
        # Exercise the real merge/retry pipeline while avoiding all API calls.
        generator = CandidateGenerator.__new__(CandidateGenerator)
        generator.max_rounds = 2
        generator._request = lambda prompt: json.dumps({"distractors": [
            {"text": f"候选{i}", "confusion_type": "同层概念混淆", "reason": "相近概念"}
            for i in range(12)
        ]}, ensure_ascii=False)
        out = generator.generate({"id": "dummy", "question": "概念问题", "correct_answer": "正解"})
        self.assertEqual(out["generation_status"], "success")
        self.assertEqual(len(out["candidate_distractors"]), 12)

    def test_gate_and_top3_no_external_deps(self):
        item = {"id": "dummy", "question": "下列术语中哪一个正确", "correct_answer": "甲类",
                "candidate_distractors": ["乙类", "丙类", "丁类", "戊类"],
                "confusion_prior": ["同层概念混淆"], "candidate_distractors_with_meta": [
                    {"text": x, "confusion_type": "同层概念混淆"} for x in ("乙类", "丙类", "丁类", "戊类")],
                "kg_neighbors": ["乙类", "丙类", "丁类", "戊类"]}
        result = rank_item(item, HybridSimilarity(), QualityConfig())
        self.assertLessEqual(result["selected_count"], 3)
        self.assertEqual(len(result["scored_candidates"]), 4)
        self.assertEqual(_percentile([1,2,3], 20), 1.4)


if __name__ == "__main__":
    unittest.main()
