"""CSV knowledge graph, entity alignment, bounded K-hop evidence extraction."""

from __future__ import annotations

import csv
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .utils import clean, norm, unique

_NODE_IDS = ("id", "node_id", "entity_id", "节点id")
_NODE_NAMES = ("name", "label", "concept", "entity", "node_name", "名称", "实体名")
_SOURCE = ("source", "src", "head", "source_id", "起点", "源节点")
_TARGET = ("target", "dst", "tail", "target_id", "终点", "目标节点")
_REL = ("relation", "predicate", "rel", "type", "关系", "关系类型")

_GROUP_KEYS = {
    "同层概念混淆": ("并列", "同层", "同类", "近义", "同级", "兄弟", "sibling", "peer"),
    "上下位层级混淆": ("属于", "包含", "上位", "下位", "父类", "子类", "实例", "组成", "part_of", "is_a"),
    "属性边界混淆": ("属性", "特征", "功能", "作用", "用于", "应用", "实现", "操作", "前置", "后继", "条件", "attribute", "property"),
}
_WEAK_REL = ("co_occur", "无关", "weak_link", "unknown")


def _read_csv(path: str | Path) -> list[dict[str, str]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
        except csv.Error:
            dialect = csv.excel
        return list(csv.DictReader(handle, dialect=dialect))


def _column(row: dict[str, str], alternatives: tuple[str, ...], required: bool = True) -> str | None:
    cols = {norm(k): k for k in row}
    for col in alternatives:
        if norm(col) in cols:
            return cols[norm(col)]
    if required:
        raise ValueError(f"CSV 缺少字段 {alternatives[0]}，实际列为 {list(row)}")
    return None


@dataclass(slots=True)
class KnowledgeGraph:
    names: dict[str, str] = field(default_factory=dict)
    name_to_id: dict[str, str] = field(default_factory=dict)
    outgoing: dict[str, list[tuple[str, str]]] = field(default_factory=lambda: defaultdict(list))
    incoming: dict[str, list[tuple[str, str]]] = field(default_factory=lambda: defaultdict(list))

    @classmethod
    def load(cls, nodes: str | Path, edges: str | Path) -> "KnowledgeGraph":
        graph = cls()
        rows = _read_csv(nodes)
        if not rows:
            raise ValueError("节点表为空。")
        id_col = _column(rows[0], _NODE_IDS, required=False)
        name_col = _column(rows[0], _NODE_NAMES)
        for index, row in enumerate(rows, 1):
            nid = clean(row.get(id_col)) if id_col else str(index)
            name = clean(row.get(name_col))
            if nid and name:
                graph.names[nid] = name
                graph.name_to_id.setdefault(norm(name), nid)

        rows = _read_csv(edges)
        if rows:
            s_col = _column(rows[0], _SOURCE)
            t_col = _column(rows[0], _TARGET)
            r_col = _column(rows[0], _REL)
            for row in rows:
                source = graph.resolve(clean(row.get(s_col)))
                target = graph.resolve(clean(row.get(t_col)))
                relation = clean(row.get(r_col))
                if source and target and relation:
                    graph.outgoing[source].append((relation, target))
                    graph.incoming[target].append((relation, source))
        return graph

    def resolve(self, token: str) -> str | None:
        return token if token in self.names else self.name_to_id.get(norm(token))

    def seed_nodes(self, item: dict[str, Any], max_seeds: int = 3) -> list[dict[str, str]]:
        explicit = item.get("seed_entities") or []
        if isinstance(explicit, str):
            explicit = [explicit]
        texts = [clean(item.get("correct_answer"))] + list(explicit)
        context = clean(item.get("question")) + " " + clean(item.get("correct_answer"))
        # Prefer longer exact concept mentions. This is deliberately deterministic.
        mentioned = [name for name in self.names.values() if len(norm(name)) >= 2 and name in context]
        texts.extend(sorted(mentioned, key=len, reverse=True))
        linked = []
        seen = set()
        for token in unique(texts):
            node_id = self.resolve(token)
            if node_id is None:
                continue
            if node_id not in seen:
                linked.append({"seed": token, "node_id": node_id, "node_name": self.names[node_id]})
                seen.add(node_id)
            if len(linked) >= max_seeds:
                break
        return linked

    def neighborhood(self, seeds: list[dict[str, str]], hop: int = 2,
                     max_neighbors: int = 16, max_paths: int = 12) -> dict[str, Any]:
        if not 1 <= hop <= 4:
            raise ValueError("hop 必须在 1~4 之间。")
        groups: dict[str, list[str]] = {key: [] for key in _GROUP_KEYS}
        neighbors: list[str] = []
        paths: list[str] = []
        origins = {s["node_id"] for s in seeds}
        queue = deque((nid, 0) for nid in origins)
        seen = set(origins)
        while queue:
            node, depth = queue.popleft()
            if depth >= hop:
                continue
            # Keep edge orientation in displayed evidence even when traversing backwards.
            adj = [(node, r, dest, dest) for r, dest in self.outgoing.get(node, [])]
            adj += [(src, r, node, src) for r, src in self.incoming.get(node, [])]
            for src, relation, dst, other in adj:
                if other not in origins:
                    neighbors.append(self.names[other])
                if not any(token in relation.lower() for token in _WEAK_REL):
                    paths.append(f"{self.names[src]} --{relation}--> {self.names[dst]}")
                    group = next((g for g, keys in _GROUP_KEYS.items() if any(k in relation.lower() for k in keys)), None)
                    if group and other not in origins:
                        groups[group].append(self.names[other])
                if other not in seen:
                    seen.add(other)
                    queue.append((other, depth + 1))
                if len(seen) > 250:
                    break
            if len(seen) > 250:
                break
        return {
            "linked_seed_entities": seeds,
            "kg_neighbors": unique(neighbors, max_neighbors),
            "kg_paths": unique(paths, max_paths),
            "kg_candidate_groups": {k: unique(v, 8) for k, v in groups.items()},
        }
