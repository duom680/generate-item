"""Four-dimensional candidate scoring, dynamic gate and redundancy-aware Top-3."""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .utils import clean, norm, unique


def _cosine(left: list[float], right: list[float]) -> float:
    dot = sum(a * b for a, b in zip(left, right))
    denom = math.sqrt(sum(x*x for x in left) * sum(x*x for x in right))
    return max(0.0, min(1.0, dot / denom)) if denom else 0.0


def _char_vector(text: str) -> Counter[str]:
    s = norm(text)
    return Counter(s[i:i+n] for n in range(1, 5) for i in range(max(len(s)-n+1, 0)))


def _lexical_fallback(a: str, b: str) -> float:
    left, right = _char_vector(a), _char_vector(b)
    union = left.keys() | right.keys()
    denom = math.sqrt(sum(v*v for v in left.values()) * sum(v*v for v in right.values()))
    return sum(left[k] * right[k] for k in union) / denom if denom else 0.0


class HybridSimilarity:
    """Original scoring design: sentence embedding + char TF-IDF, or lexical-only.

    Dense mode is opt-in with an *existing local model directory*. This public
    version never downloads model weights on its own.
    """

    def __init__(self, local_embedding_model: str | None = None,
                 dense_weight: float = 0.70) -> None:
        self.model = None
        self.dense_weight = dense_weight
        self.cache: dict[str, Any] = {}
        if local_embedding_model:
            path = Path(local_embedding_model)
            if not path.is_dir():
                raise ValueError("句向量模型必须是本机已存在的文件夹路径。")
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(str(path), local_files_only=True)

    def _lexical(self, a: str, b: str) -> float:
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity
            cleaned = [norm(a), norm(b)]
            if not cleaned[0] or not cleaned[1]:
                return 0.0
            matrix = TfidfVectorizer(analyzer="char", ngram_range=(1, 4)).fit_transform(cleaned)
            return float(cosine_similarity(matrix[0], matrix[1])[0, 0])
        except ImportError:
            return _lexical_fallback(a, b)
        except ValueError:
            return 0.0

    def _encode(self, value: str) -> list[float]:
        if value not in self.cache:
            embedding = self.model.encode([value], normalize_embeddings=False)[0]
            self.cache[value] = embedding.tolist() if hasattr(embedding, "tolist") else list(embedding)
        return self.cache[value]

    def __call__(self, a: str, b: str) -> float:
        lexical = self._lexical(a, b)
        if self.model is None:
            return max(0.0, min(1.0, lexical))
        dense = _cosine(self._encode(a), self._encode(b))
        return max(0.0, min(1.0, self.dense_weight*dense+(1-self.dense_weight)*lexical))


def _percentile(values: list[float], percent: float) -> float:
    """Linear-interpolated percentiles, as in numpy.percentile."""
    if not values:
        return 0.0
    data = sorted(values)
    position = (len(data) - 1) * (percent / 100.0)
    lo, hi = math.floor(position), math.ceil(position)
    return data[lo] + (position-lo) * (data[hi]-data[lo])


def _shape(answer: str, candidate: str, explicit: str = "") -> float:
    shape = explicit
    if not shape:
        if any(x in answer for x in ("、", "，", ",", ";", "；")):
            shape = "列表型"
        elif any(x in answer for x in ("和", "与")):
            shape = "并列型"
        elif len(answer) > 12:
            shape = "描述型"
        else:
            shape = "术语型"
    if shape == "列表型":
        return 1.0 if any(x in candidate for x in ("、", "，", ",", "和", "与")) else 0.45
    if shape == "并列型":
        return 1.0 if any(x in candidate for x in ("和", "与", "、", "，")) else 0.35
    if shape == "术语型":
        return 1.0 if len(candidate) <= 12 else (0.75 if len(candidate) <= 18 else 0.45)
    ratio = min(len(candidate), len(answer)) / max(len(candidate), len(answer), 1)
    return min(1.0, max(0.35, ratio))


def _equivalent(candidate: str, answer: str, sim_answer: float,
                threshold: float = 0.92) -> bool:
    c, a = norm(candidate), norm(answer)
    if not c or not a:
        return True
    if c == a or sim_answer >= threshold:
        return True
    return (c in a or a in c) and min(len(c), len(a))/max(len(c), len(a)) >= 0.85


def _kg_score(candidate: str, item: dict[str, Any], sim: HybridSimilarity,
              meta: dict[str, dict[str, str]]) -> float:
    groups = item.get("kg_candidate_groups") or {}
    base = {"同层概念混淆": 0.78, "上下位层级混淆": 0.72, "属性边界混淆": 0.70}
    direct = 0.0
    key = norm(candidate)
    for gname, nodes in groups.items():
        for node in nodes:
            nk = norm(node)
            if not nk:
                continue
            strength = base.get(gname, 0.62)
            if key == nk:
                direct = max(direct, strength)
            elif key in nk or nk in key:
                direct = max(direct, strength*(0.7+0.25*min(len(key),len(nk))/max(len(key),len(nk))))
    evidence = item.get("kg_neighbors", []) + [s.get("node_name", "") for s in item.get("linked_seed_entities", [])]
    for path in item.get("kg_paths", []):
        match = re.match(r"^(.*?)\s*--(.*?)-->\s*(.*)$", path)
        if match:
            src, rel, dst = (x.strip() for x in match.groups())
            if "无关" not in rel and "co_occur" not in rel:
                evidence.extend([src, dst])
    evidence = unique(evidence, 18)
    semantic = min(0.68, 0.78*max((sim(candidate, t) for t in evidence), default=0.0))
    ctype = clean(meta.get(norm(candidate), {}).get("confusion_type"))
    prior = item.get("confusion_prior", [])
    prior_score = 0.72 if ctype in prior else (0.58 if ctype else 0.0)
    return max(direct, semantic, prior_score)


@dataclass(frozen=True)
class QualityConfig:
    w_sim: float = 0.20
    w_q: float = 0.35
    w_kg: float = 0.25
    w_div: float = 0.20
    gate_percentile: float = 20.0
    min_quality_score: float = 0.18
    min_q: float = 0.10
    min_sim: float = 0.08
    min_kg: float = 0.25
    duplicate_threshold: float = 0.86

    def __post_init__(self) -> None:
        if sum((self.w_sim, self.w_q, self.w_kg, self.w_div)) <= 0:
            raise ValueError("四维权重之和必须大于 0。")
        if not 0 <= self.gate_percentile <= 100:
            raise ValueError("gate_percentile 需在 0~100 之间。")


def rank_item(item: dict[str, Any], similarity: HybridSimilarity,
              config: QualityConfig | None = None) -> dict[str, Any]:
    cfg = config or QualityConfig()
    answer = clean(item["correct_answer"])
    candidates = [v for v in unique(item.get("candidate_distractors") or [])
                  if len(v) <= 80 and not any(t in v for t in ("以上都", "正确答案", "干扰项", "解析"))]
    metadata = {norm(v.get("text")): v for v in item.get("candidate_distractors_with_meta", []) if isinstance(v, dict)}
    question_context = " ".join(str(x) for x in (
        item.get("chapter", ""), item.get("question_type", ""),
        item.get("question_polarity", ""), item.get("question", ""),
        " ".join(item.get("confusion_prior", []))))
    weight_sum = sum((cfg.w_sim, cfg.w_q, cfg.w_kg, cfg.w_div))
    rows: list[dict[str, Any]] = []
    for candidate in candidates:
        s_sim = similarity(candidate, answer)
        s_q = similarity(candidate, question_context)
        s_kg = _kg_score(candidate, item, similarity, metadata)
        other_similarity = max((similarity(candidate, other) for other in candidates if other != candidate), default=0.0)
        s_div = max(0.0, 1.0 - other_similarity)
        shape = _shape(answer, candidate, clean(item.get("answer_shape")))
        effective_sim = min(s_sim, 0.65) if item.get("question_polarity") == "否定题" else s_sim
        composite = (cfg.w_sim*effective_sim+cfg.w_q*s_q+cfg.w_kg*s_kg+cfg.w_div*s_div)/weight_sum
        adjusted = composite * (0.72 + 0.28*shape)
        equivalent = _equivalent(candidate, answer, s_sim)
        shape_risk = shape < 0.35
        low_relevance = (s_q < cfg.min_q and s_kg < cfg.min_kg and s_sim < cfg.min_sim)
        kg_only = (s_kg >= 0.72 and s_q < cfg.min_q and s_sim < cfg.min_sim)
        hard_pass = not (equivalent or shape_risk or low_relevance or kg_only)
        rows.append({
            "candidate": candidate,
            "s_sim": round(s_sim, 4), "s_q": round(s_q, 4),
            "s_kg": round(s_kg, 4), "s_div": round(s_div, 4),
            "composite_score": round(composite, 4),
            "adjusted_score": round(adjusted, 4),
            "hard_pass": hard_pass,
            "equivalent_risk": equivalent,
            "shape_risk": shape_risk,
        })
    eligible = [x for x in rows if x["hard_pass"]]
    threshold = max(cfg.min_quality_score, _percentile([x["adjusted_score"] for x in eligible], cfg.gate_percentile))
    for row in rows:
        row["gate_threshold"] = round(threshold, 4)
        row["gate_pass"] = row["hard_pass"] and row["adjusted_score"] >= threshold
    passed = [x for x in rows if x["gate_pass"]]
    # If gated pool is too small, fall back to hard-pass only; never admit hard failures.
    pool = passed if len(passed) >= 3 else eligible
    pool = sorted(pool, key=lambda x: x["adjusted_score"], reverse=True)
    selected: list[dict[str, Any]] = []
    for row in pool:
        if all(similarity(row["candidate"], prev["candidate"]) < cfg.duplicate_threshold for prev in selected):
            selected.append(row)
        if len(selected) == 3:
            break
    if len(selected) < 3:
        seen = {r["candidate"] for r in selected}
        selected.extend(x for x in pool if x["candidate"] not in seen)
    selected = selected[:3]
    selected_names = {x["candidate"] for x in selected}
    for row in rows:
        row["selected"] = row["candidate"] in selected_names
    return {
        **item,
        "scored_candidates": sorted(rows, key=lambda x: x["adjusted_score"], reverse=True),
        "selected_distractors": [x["candidate"] for x in selected],
        "selected_count": len(selected),
        "selection_status": "success" if len(selected) == 3 else "partial_need_regeneration",
    }
