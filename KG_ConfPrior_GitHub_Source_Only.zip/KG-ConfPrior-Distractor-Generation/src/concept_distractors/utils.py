"""Small, dependency-free I/O and normalization helpers."""

from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path
from typing import Any


def clean(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def norm(value: Any) -> str:
    return re.sub(r"[\s\W_]+", "", unicodedata.normalize("NFKC", clean(value)).casefold())


def unique(items: list[str], limit: int | None = None) -> list[str]:
    out, seen = [], set()
    for value in items:
        value = clean(value)
        key = norm(value)
        if key and key not in seen:
            out.append(value)
            seen.add(key)
            if limit is not None and len(out) >= limit:
                break
    return out


def read_items(path: str | Path) -> list[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8-sig") as handle:
        data = json.load(handle)
    if not isinstance(data, list) or any(not isinstance(x, dict) for x in data):
        raise ValueError("题目文件必须是 JSON 对象数组。")
    ids = [str(x.get("id", "")).strip() for x in data]
    if not all(ids) or len(ids) != len(set(ids)):
        raise ValueError("每道题必须具有非空且唯一的 id。")
    for row in data:
        if not clean(row.get("question")) or not clean(row.get("correct_answer")):
            raise ValueError(f"题号 {row['id']} 缺少 question 或 correct_answer。")
    return data


def write_json(path: str | Path, data: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
    tmp.replace(path)
