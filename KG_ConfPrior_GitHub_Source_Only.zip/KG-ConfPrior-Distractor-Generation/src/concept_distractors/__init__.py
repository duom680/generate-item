"""KG-constrained, confusion-prior-guided distractor generation (public core)."""

__version__ = "0.1.0"
