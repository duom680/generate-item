"""Explicit, question-sensitive concept-confusion priors."""

from __future__ import annotations

from typing import Any

from .utils import clean

_NEGATIVE = ("不正确", "错误", "不是", "不属于", "无关", "不具有", "不能", "不包括", "最不适合", "不适合")
_TYPES = {
    "概念定义": ("定义", "是指", "称为", "指的是"),
    "概念分类": ("分为", "属于", "哪一类", "以下属于"),
    "应用场景": ("适用", "应用", "用于", "场景", "适合"),
    "性质辨析": ("特点", "性质", "正确的是", "错误的是", "区别", "优点", "作用"),
    "结构特征": ("结构", "组成", "存储", "层级", "连接", "结点"),
    "过程操作": ("步骤", "前置", "后继", "操作", "执行", "条件", "流程"),
}
_PRIORS = {
    "概念定义": ["同层概念混淆", "上下位层级混淆", "属性边界混淆"],
    "概念分类": ["同层概念混淆", "上下位层级混淆"],
    "结构特征": ["属性边界混淆", "同层概念混淆", "上下位层级混淆"],
    "应用场景": ["属性边界混淆", "同层概念混淆"],
    "性质辨析": ["属性边界混淆", "同层概念混淆", "上下位层级混淆"],
    "过程操作": ["过程操作混淆", "属性边界混淆", "同层概念混淆"],
    "概念辨析": ["同层概念混淆", "属性边界混淆", "上下位层级混淆"],
}


def prepare_item(item: dict[str, Any], graph: Any, hop: int = 2) -> dict[str, Any]:
    question = clean(item["question"])
    polarity = "否定题" if any(marker in question for marker in _NEGATIVE) else "正向题"
    question_type = clean(item.get("question_type"))
    if question_type not in _PRIORS:
        question_type = next((kind for kind, clues in _TYPES.items() if any(k in question for k in clues)), "概念辨析")
    seeds = graph.seed_nodes(item)
    evidence = graph.neighborhood(seeds, hop=hop)
    return {
        **item,
        "question_type": question_type,
        "question_polarity": polarity,
        "confusion_prior": _PRIORS[question_type],
        "confusion_scope_text": (
            "否定题：干扰项不应同样满足题干的否定条件，须避免多个正确选项。"
            if polarity == "否定题" else
            "正向题：干扰项须与正确答案在概念邻域上相关，但不可同时构成正确答案。"
        ),
        **evidence,
    }
