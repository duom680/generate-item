"""OpenAI-compatible candidate generation using environment-only credentials."""

from __future__ import annotations

import json
import os
import re
import time
from typing import Any

from .prompts import SYSTEM_PROMPT, build_user_prompt
from .utils import clean, norm

_ALLOWED = {
    "同层概念混淆", "上下位层级混淆", "属性边界混淆",
    "过程操作混淆", "应用场景混淆", "表述边界混淆",
}


def parse_candidates(message: str, correct_answer: str) -> list[dict[str, str]]:
    text = clean(message)
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
    data = json.loads(text)
    entries = data.get("distractors")
    if not isinstance(entries, list):
        raise ValueError("模型未返回 distractors 数组。")
    out: list[dict[str, str]] = []
    seen = {norm(correct_answer)}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        option = re.sub(r"^\s*(?:[A-Da-d][.、．)]|\d+[.、．)])\s*", "", clean(entry.get("text")))
        key = norm(option)
        if not key or key in seen or len(option) > 90:
            continue
        if any(w in option for w in ("以上都是", "以上都不是")):
            continue
        seen.add(key)
        ctype = clean(entry.get("confusion_type"))
        out.append({
            "text": option,
            "confusion_type": ctype if ctype in _ALLOWED else "表述边界混淆",
            "reason": clean(entry.get("reason"))[:120],
        })
    return out


class CandidateGenerator:
    def __init__(self, model: str, temperature: float = 0.3,
                 max_retries: int = 3, max_rounds: int = 2) -> None:
        # No key, token, or provider URL appears in repository source or outputs.
        token = os.environ.get("OPENAI_API_KEY")
        if not token:
            raise RuntimeError("未配置 OPENAI_API_KEY 环境变量。")
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("缺少运行时 API 客户端，请在本地环境配置。") from exc
        kwargs: dict[str, Any] = {"api_key": token}
        if os.environ.get("OPENAI_BASE_URL"):
            kwargs["base_url"] = os.environ["OPENAI_BASE_URL"]
        self.client = OpenAI(**kwargs)
        self.model = model
        self.temperature = temperature
        self.max_retries = max_retries
        self.max_rounds = max_rounds

    def _request(self, prompt: str) -> str:
        for attempt in range(self.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                    temperature=self.temperature,
                    max_tokens=3200,
                )
                return (response.choices[0].message.content or "").strip()
            except Exception as exc:
                # Never print provider exception payloads; some contain headers/URLs.
                if attempt + 1 >= self.max_retries:
                    raise RuntimeError("候选生成调用失败，已达到重试上限。") from None
                time.sleep(min(2 ** attempt, 8))
        raise RuntimeError("候选生成失败。")

    def generate(self, item: dict[str, Any], target: int = 12) -> dict[str, Any]:
        collected: list[dict[str, str]] = []
        existing: set[str] = {norm(item["correct_answer"])}
        for _ in range(self.max_rounds):
            remaining = target - len(collected)
            if remaining <= 0:
                break
            raw = self._request(build_user_prompt(item, remaining, [x["text"] for x in collected]))
            try:
                batch = parse_candidates(raw, item["correct_answer"])
            except (ValueError, json.JSONDecodeError):
                continue
            for candidate in batch:
                key = norm(candidate["text"])
                if key not in existing:
                    collected.append(candidate)
                    existing.add(key)
                    if len(collected) >= target:
                        break
        return {
            **item,
            "candidate_distractors": [x["text"] for x in collected],
            "candidate_distractors_with_meta": collected,
            "generation_status": "success" if len(collected) == target else "partial_need_review",
        }
